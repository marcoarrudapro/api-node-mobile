const Product = require('../models/produto');

class ProductRepository{
    async createProduct(product){
        return await Product.create(product);
    }

    async findByName(name){
        return await Product.findOne({where: {name}})
    }

    async findAll(){
        return await Product.findAll();
    }
}

module.exports = new ProductRepository();