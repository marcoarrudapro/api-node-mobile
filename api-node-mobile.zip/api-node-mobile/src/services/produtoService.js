const bcrypt = require('bcrypt');
const productRepository = require('../repositories/produtoRepository');
const { v4: UUIDV4 } = require('uuid');


class ProductService{
    async register(name, price, description, category){
        const getproduct = await this.getByName(name);
        console.log(getproduct);
        if(getproduct){
            throw new Error('Nome já cadastrado');
        }

        if (name.lenght < 10 || name.lenght > 60){
            throw new Error('Nome deve ter entre 10 e 60 caracteres')
        }

        if (description.lenght < 10 || description.lenght > 500){
            throw new Error('A descrição deve ter entre 10 e 500 caracteres')
        }

        if (category.lenght <10 || category.lenght > 30){
            throw new Error('A categoria deve ter entre 10 e 30 caracteres')
        }

        const product = await productRepository.createProduct({id: UUIDV4(), name, price, description,catogory: category});
        return product;
    }

    async getByName(name){
        return await productRepository.findByName(name);
    
    }

    async getProduct(){
        return await productRepository.findAll();
    }
}

module.exports = new ProductService();